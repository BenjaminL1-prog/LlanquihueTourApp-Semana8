package data;

import java.util.ArrayList;
import java.util.List;

import model.ExcursionCultural;
import model.PaseoLacustre;
import model.RutaGastronomica;
import model.ServicioTuristico;

public class GestorServicios {

    private List<ServicioTuristico> servicios;

    public GestorServicios() {

        servicios = new ArrayList<>();

        servicios.add(new RutaGastronomica("Ruta del Queso", 4, 5));
        servicios.add(new RutaGastronomica("Ruta del Chocolate", 3, 4));

        servicios.add(new PaseoLacustre("Lago Llanquihue", 2, "Catamarán"));
        servicios.add(new PaseoLacustre("Lago Todos los Santos", 5, "Lancha"));

        servicios.add(new ExcursionCultural("Museo Colonial", 3, "Fuerte Niebla"));
        servicios.add(new ExcursionCultural("Patrimonio Alemán", 4, "Frutillar"));
    }

    public void mostrarServicios() {

        for (ServicioTuristico servicio : servicios) {
            servicio.mostrarInformacion();
            System.out.println();
        }
    }
}