package data;

import model.ColaboradorExterno;
import model.GuiaTuristico;
import model.Registrable;
import model.Vehiculo;

import java.util.ArrayList;

public class GestorEntidades {

    private ArrayList<Registrable> entidades;

    public GestorEntidades() {
        entidades = new ArrayList<>();
    }

    public void agregarEntidad(Registrable entidad) {
        entidades.add(entidad);
    }

    public void mostrarEntidades() {

        for (Registrable entidad : entidades) {

            System.out.println(entidad.mostrarResumen());

            if (entidad instanceof GuiaTuristico) {
                System.out.println("→ Esta entidad corresponde a un Guía Turístico.");
            } else if (entidad instanceof Vehiculo) {
                System.out.println("→ Esta entidad corresponde a un Vehículo.");
            } else if (entidad instanceof ColaboradorExterno) {
                System.out.println("→ Esta entidad corresponde a un Colaborador Externo.");
            }

            System.out.println("----------------------------------------");
        }

    }

}