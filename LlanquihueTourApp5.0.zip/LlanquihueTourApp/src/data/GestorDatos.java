package data;

import model.Tour;
import model.Proveedor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class GestorDatos {

    // =========================
    // CARGA DE DATOS DESDE ARCHIVO
    // =========================
    public ArrayList<Tour> cargarTours(String rutaArchivo) {

        ArrayList<Tour> tours = new ArrayList<>();

        try {

            BufferedReader br = new BufferedReader(new FileReader(rutaArchivo));

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(";");

                String nombre = datos[0];
                String tipo = datos[1];
                int precio = Integer.parseInt(datos[2]);

                // COMPOSICIÓN (Tour tiene Proveedor)
                Proveedor proveedor = new Proveedor(
                        "Proveedor Local",
                        "+56 9 1234 5678"
                );

                Tour tour = new Tour(nombre, tipo, precio, proveedor);

                tours.add(tour);
            }

            br.close();

        } catch (Exception e) {
            System.out.println("Error al leer archivo: " + e.getMessage());
        }

        return tours;
    }

    // =========================
    // BÚSQUEDA SIMPLE (REQUERIDA POR PAUTA)
    // =========================
    public void buscarPorTipo(ArrayList<Tour> tours, String tipo) {

        System.out.println("\n=== RESULTADOS DE BÚSQUEDA ===");

        for (Tour t : tours) {

            if (t.getTipo().equalsIgnoreCase(tipo)) {
                System.out.println(t);
            }
        }
    }

    // =========================
    // (OPCIONAL PERO SUMA) BÚSQUEDA POR NOMBRE
    // =========================
    public void buscarPorNombre(ArrayList<Tour> tours, String nombre) {

        System.out.println("\n=== BÚSQUEDA POR NOMBRE ===");

        for (Tour t : tours) {

            if (t.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println(t);
            }
        }
    }
}