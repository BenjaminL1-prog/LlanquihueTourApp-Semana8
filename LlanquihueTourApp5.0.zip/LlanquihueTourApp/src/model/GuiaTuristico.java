package model;

public class GuiaTuristico extends Persona {

    private String especialidad;
    private int aniosExperiencia;

    public GuiaTuristico(String nombre, String rut, String especialidad, int aniosExperiencia) {
        super(nombre, rut);
        this.especialidad = especialidad;
        this.aniosExperiencia = aniosExperiencia;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getAniosExperiencia() {
        return aniosExperiencia;
    }

    public void setAniosExperiencia(int aniosExperiencia) {
        this.aniosExperiencia = aniosExperiencia;
    }

    @Override
    public String mostrarResumen() {
        return "Guía Turístico: " + getNombre()
                + " | RUT: " + getRut()
                + " | Especialidad: " + especialidad
                + " | Experiencia: " + aniosExperiencia + " años";
    }
}