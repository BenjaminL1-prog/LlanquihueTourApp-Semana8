package model;

public abstract class RecursoAgencia implements Registrable {

    private String codigo;

    public RecursoAgencia(String codigo) {
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}