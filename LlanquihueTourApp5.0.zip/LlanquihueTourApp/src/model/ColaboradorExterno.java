package model;

public class ColaboradorExterno extends Persona {

    private String empresa;

    public ColaboradorExterno(String nombre, String rut, String empresa) {
        super(nombre, rut);
        this.empresa = empresa;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    @Override
    public String mostrarResumen() {
        return "Colaborador Externo: " + getNombre()
                + " | RUT: " + getRut()
                + " | Empresa: " + empresa;
    }
}