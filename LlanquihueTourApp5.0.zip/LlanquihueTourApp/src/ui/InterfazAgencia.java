package ui;

import data.GestorEntidades;
import model.ColaboradorExterno;
import model.GuiaTuristico;
import model.Vehiculo;

import javax.swing.JOptionPane;

public class InterfazAgencia {

    private GestorEntidades gestorEntidades;


    public InterfazAgencia(GestorEntidades gestorEntidades) {

        this.gestorEntidades = gestorEntidades;

    }


    public void iniciar() {

        int opcion;

        do {

            String menu = """
                    
                    ===== LLANQUIHUE TOUR =====
                    
                    1. Registrar Guía Turístico
                    2. Registrar Vehículo
                    3. Registrar Colaborador Externo
                    4. Mostrar entidades
                    5. Salir
                    
                    Seleccione una opción:
                    """;


            String entrada = JOptionPane.showInputDialog(menu);


            if (entrada == null) {

                JOptionPane.showMessageDialog(
                        null,
                        "¡Hasta luego!"
                );

                break;

            }


            opcion = Integer.parseInt(entrada);


            switch (opcion) {

                case 1 -> registrarGuia();

                case 2 -> registrarVehiculo();

                case 3 -> registrarColaborador();


                case 4 -> {

                    System.out.println("\n=== ENTIDADES DE LA AGENCIA ===");

                    gestorEntidades.mostrarEntidades();

                    JOptionPane.showMessageDialog(
                            null,
                            "Las entidades fueron mostradas en la consola."
                    );

                }


                case 5 ->

                        JOptionPane.showMessageDialog(
                                null,
                                "¡Hasta luego!"
                        );


                default ->

                        JOptionPane.showMessageDialog(
                                null,
                                "Opción no válida."
                        );

            }


        } while (opcion != 5);

    }



    private void registrarGuia() {

        String nombre = JOptionPane.showInputDialog("Nombre:");
        String rut = JOptionPane.showInputDialog("RUT:");
        String especialidad = JOptionPane.showInputDialog("Especialidad:");

        int experiencia = Integer.parseInt(
                JOptionPane.showInputDialog("Años de experiencia:")
        );


        gestorEntidades.agregarEntidad(
                new GuiaTuristico(
                        nombre,
                        rut,
                        especialidad,
                        experiencia
                )
        );


        JOptionPane.showMessageDialog(
                null,
                "Guía registrado correctamente."
        );

    }



    private void registrarVehiculo() {

        String patente = JOptionPane.showInputDialog("Patente:");
        String modelo = JOptionPane.showInputDialog("Modelo:");

        int capacidad = Integer.parseInt(
                JOptionPane.showInputDialog("Capacidad de pasajeros:")
        );


        gestorEntidades.agregarEntidad(
                new Vehiculo(
                        patente,
                        modelo,
                        capacidad
                )
        );


        JOptionPane.showMessageDialog(
                null,
                "Vehículo registrado correctamente."
        );

    }



    private void registrarColaborador() {

        String nombre = JOptionPane.showInputDialog("Nombre:");
        String rut = JOptionPane.showInputDialog("RUT:");
        String empresa = JOptionPane.showInputDialog("Empresa:");


        gestorEntidades.agregarEntidad(
                new ColaboradorExterno(
                        nombre,
                        rut,
                        empresa
                )
        );


        JOptionPane.showMessageDialog(
                null,
                "Colaborador registrado correctamente."
        );

    }

}