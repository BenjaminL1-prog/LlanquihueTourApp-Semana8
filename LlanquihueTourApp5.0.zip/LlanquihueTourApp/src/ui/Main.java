package ui;

import data.GestorDatos;
import data.GestorEntidades;
import data.GestorServicios;
import model.ColaboradorExterno;
import model.GuiaTuristico;
import model.Tour;
import model.Vehiculo;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        // ============================
        // ACTIVIDAD SEMANAS ANTERIORES
        // ============================

        GestorDatos gestor = new GestorDatos();

        ArrayList<Tour> tours = gestor.cargarTours("resources/tours.txt");

        System.out.println("=== TODOS LOS TOURS ===");

        for (Tour tour : tours) {
            System.out.println(tour);
        }

        System.out.println("\n=== TOURS SOBRE $20.000 ===");

        for (Tour tour : tours) {

            if (tour.getPrecio() > 20000) {
                System.out.println(tour);
            }
        }

        // Buscador
        gestor.buscarPorTipo(tours, "Lacustre");


        // ============================
        // ACTIVIDAD SEMANA 6
        // ============================

        System.out.println("\n=== SERVICIOS TURÍSTICOS ===");

        GestorServicios gestorServicios = new GestorServicios();
        gestorServicios.mostrarServicios();


        // ============================
        // ACTIVIDAD SEMANA 8
        // ============================



        GestorEntidades gestorEntidades = new GestorEntidades();

        gestorEntidades.agregarEntidad(
                new GuiaTuristico(
                        "María González",
                        "12.345.678-9",
                        "Turismo de Montaña",
                        8
                )
        );

        gestorEntidades.agregarEntidad(
                new Vehiculo(
                        "ABCD-12",
                        "Mercedes Sprinter",
                        18
                )
        );

        gestorEntidades.agregarEntidad(
                new ColaboradorExterno(
                        "Juan Pérez",
                        "18.765.432-1",
                        "Hotel Patagonia"
                )
        );


        // ============================
        // INTERFAZ DE USUARIO
        // ============================

        InterfazAgencia interfaz = new InterfazAgencia(gestorEntidades);

        interfaz.iniciar();

    }
}